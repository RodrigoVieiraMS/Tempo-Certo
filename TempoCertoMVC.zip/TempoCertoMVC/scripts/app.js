document.getElementById("search").addEventListener("click", () => {
  const city = document.getElementById("cityName").value;
console.log("Cidade inserida:", city); 

  if (!city) {
    //CIDADE ESTIVER VAZIA
    document.getElementById("errorBox").classList.add("show");
    document.getElementById("tempBox").classList.remove("show");
  } else {
    //CIDADE NÃO ESTIVER VAZIA
    document.getElementById("errorBox").classList.remove("show");
    document.getElementById("tempBox").style.display = "none"; 
    document.getElementById("tempBox").classList.remove("show");

    const apiKey = "010471da33aa5bd03a4c2658fcdf3194";
    const apiUrl = `https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${apiKey}&units=metric&lang=pt_br`;

    fetch(apiUrl)
      .then(response => response.json())
      .then(data => {
        if (data.cod === 200) {
          const temp = data.main.temp;
          document.getElementById("temp").innerText = temp;
          document.getElementById("tempBox").style.display = "block";
          document.getElementById("tempBox").classList.add("show");
        } else {
          //CIDADE NÃO ENCONTRADA
          document.getElementById("errorBox").classList.add("show");
          document.getElementById("tempBox").classList.remove("show");
        }
      })
      .catch(error => {
        console.error("Erro ao consultar a API:", error);
        document.getElementById("errorBox").classList.add("show");
        document.getElementById("tempBox").classList.remove("show");
      });
  }
});
