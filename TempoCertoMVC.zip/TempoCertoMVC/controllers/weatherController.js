import { getWeatherData } from "../models/weatherModel.js"; 

//BUSCA DA TEMPERATURA
const handleSearch = async () => {
  const cityName = document.getElementById('cityName').value; //PEGA A CIDADE

  if (!cityName) {
    showError("Por favor, insira o nome da cidade!"); //ERRO
    return;
  }

  //API
  const apiKey = "010471da33aa5bd03a4c2658fcdf3194"; 
  const url = `https://api.openweathermap.org/data/2.5/weather?q=${cityName}&appid=${apiKey}&units=metric`;

  try {
    const response = await fetch(url);
    const data = await response.json();

    if (data.cod === '404') {
      showError("Cidade não encontrada!"); //ERRO
      return;
    }

    updateWeatherInfo(data); //ATT A TEMPERATURA
  } catch (error) {
    showError("Erro ao buscar o clima!"); //ERRO
  }
};

document.getElementById('search').addEventListener('click', handleSearch);

document.getElementById('cityName').addEventListener('keypress', function(event) {
  if (event.key === 'Enter') {
    handleSearch();
  }
});

//BOX DE ERRO
const showError = (message) => {
  const errorBox = document.getElementById('errorBox');
  errorBox.textContent = message;
  errorBox.classList.add('show');
  setTimeout(() => errorBox.classList.remove('show'), 3000); // Esconde após 3 segundos
};

//BOX DE ATT DE TEMPERATURA
const updateWeatherInfo = (data) => {
  const tempBox = document.getElementById('tempBox');
  tempBox.textContent = `Temperatura em ${data.name}: ${data.main.temp}°C`;
  tempBox.classList.add('show');
  setTimeout(() => tempBox.classList.remove('show'), 5000); 
};

export default { handleSearch };