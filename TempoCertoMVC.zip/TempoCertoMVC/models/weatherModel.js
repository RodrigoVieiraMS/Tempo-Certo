import axios from "axios"; 

const apiKey = "010471da33aa5bd03a4c2658fcdf3194"; 

export const getWeatherData = async (cityName) => {
  try {
    const response = await axios.get(
      `https://api.openweathermap.org/data/2.5/weather?q=${cityName}&appid=${apiKey}&units=metric&lang=pt_br`
    );
    return response.data; 
  } catch (error) {
    console.error("Erro ao buscar dados de clima:", error); 
    throw new Error("Cidade não encontrada. Tente novamente.");
  }
};
